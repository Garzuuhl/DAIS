#include <QtQml/qqmlprivate.h>
#include <QtCore/qdir.h>
#include <QtCore/qurl.h>

static const unsigned char qt_resource_tree[] = {
0,
0,0,0,0,2,0,0,0,1,0,0,0,1,0,0,0,
8,0,2,0,0,0,12,0,0,0,2,0,0,0,158,0,
0,0,0,0,1,0,0,0,0,0,0,1,28,0,0,0,
0,0,1,0,0,0,0,0,0,1,98,0,0,0,0,0,
1,0,0,0,0,0,0,0,52,0,0,0,0,0,1,0,
0,0,0,0,0,0,250,0,0,0,0,0,1,0,0,0,
0,0,0,1,126,0,0,0,0,0,1,0,0,0,0,0,
0,0,226,0,0,0,0,0,1,0,0,0,0,0,0,1,
60,0,0,0,0,0,1,0,0,0,0,0,0,0,192,0,
0,0,0,0,1,0,0,0,0,0,0,0,20,0,0,0,
0,0,1,0,0,0,0,0,0,0,86,0,0,0,0,0,
1,0,0,0,0,0,0,0,122,0,0,0,0,0,1,0,
0,0,0};
static const unsigned char qt_resource_names[] = {
0,
1,0,0,0,47,0,47,0,3,0,0,120,60,0,113,0,
109,0,108,0,13,13,148,135,60,0,100,0,97,0,115,0,
104,0,98,0,111,0,97,0,114,0,100,0,46,0,113,0,
109,0,108,0,14,5,251,201,60,0,84,0,97,0,99,0,
104,0,111,0,77,0,101,0,116,0,101,0,114,0,46,0,
113,0,109,0,108,0,15,15,8,226,92,0,76,0,101,0,
102,0,116,0,83,0,105,0,103,0,110,0,97,0,108,0,
115,0,46,0,113,0,109,0,108,0,15,15,228,235,188,0,
86,0,97,0,108,0,117,0,101,0,83,0,111,0,117,0,
114,0,99,0,101,0,46,0,113,0,109,0,108,0,14,1,
78,243,220,0,84,0,101,0,109,0,112,0,87,0,97,0,
115,0,115,0,101,0,114,0,46,0,113,0,109,0,108,0,
14,13,63,38,28,0,70,0,117,0,101,0,108,0,83,0,
121,0,115,0,116,0,101,0,109,0,46,0,113,0,109,0,
108,0,9,10,244,243,92,0,77,0,101,0,100,0,105,0,
97,0,46,0,113,0,109,0,108,0,14,7,178,105,60,0,
83,0,112,0,101,0,101,0,100,0,77,0,101,0,116,0,
101,0,114,0,46,0,113,0,109,0,108,0,13,4,121,201,
83,0,77,0,97,0,116,0,104,0,72,0,101,0,108,0,
112,0,101,0,114,0,46,0,106,0,115,0,16,11,19,159,
220,0,82,0,105,0,103,0,104,0,116,0,83,0,105,0,
103,0,110,0,97,0,108,0,115,0,46,0,113,0,109,0,
108,0,11,5,74,224,156,0,84,0,101,0,109,0,112,0,
79,0,105,0,108,0,46,0,113,0,109,0,108,0,13,8,
205,4,28,0,67,0,97,0,114,0,83,0,116,0,97,0,
116,0,117,0,115,0,46,0,113,0,109,0,108};
static const unsigned char qt_resource_empty_payout[] = { 0, 0, 0, 0, 0 };
QT_BEGIN_NAMESPACE
extern Q_CORE_EXPORT bool qRegisterResourceData(int, const unsigned char *, const unsigned char *, const unsigned char *);
QT_END_NAMESPACE
namespace QmlCacheGeneratedCode {
namespace _qml_CarStatus_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_TempOil_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_RightSignals_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_MathHelper_js { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_SpeedMeter_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_Media_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_FuelSystem_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_TempWasser_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_ValueSource_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_LeftSignals_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_TachoMeter_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}
namespace _qml_dashboard_qml { 
    extern const unsigned char qmlData[];
    const QQmlPrivate::CachedQmlUnit unit = {
        reinterpret_cast<const QV4::CompiledData::Unit*>(&qmlData), nullptr, nullptr
    };
}

}
namespace {
struct Registry {
    Registry();
    ~Registry();
    QHash<QString, const QQmlPrivate::CachedQmlUnit*> resourcePathToCachedUnit;
    static const QQmlPrivate::CachedQmlUnit *lookupCachedUnit(const QUrl &url);
};

Q_GLOBAL_STATIC(Registry, unitRegistry)


Registry::Registry() {
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/CarStatus.qml"), &QmlCacheGeneratedCode::_qml_CarStatus_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/TempOil.qml"), &QmlCacheGeneratedCode::_qml_TempOil_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/RightSignals.qml"), &QmlCacheGeneratedCode::_qml_RightSignals_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/MathHelper.js"), &QmlCacheGeneratedCode::_qml_MathHelper_js::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/SpeedMeter.qml"), &QmlCacheGeneratedCode::_qml_SpeedMeter_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/Media.qml"), &QmlCacheGeneratedCode::_qml_Media_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/FuelSystem.qml"), &QmlCacheGeneratedCode::_qml_FuelSystem_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/TempWasser.qml"), &QmlCacheGeneratedCode::_qml_TempWasser_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/ValueSource.qml"), &QmlCacheGeneratedCode::_qml_ValueSource_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/LeftSignals.qml"), &QmlCacheGeneratedCode::_qml_LeftSignals_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/TachoMeter.qml"), &QmlCacheGeneratedCode::_qml_TachoMeter_qml::unit);
        resourcePathToCachedUnit.insert(QStringLiteral("/qml/dashboard.qml"), &QmlCacheGeneratedCode::_qml_dashboard_qml::unit);
    QQmlPrivate::RegisterQmlUnitCacheHook registration;
    registration.version = 0;
    registration.lookupCachedQmlUnit = &lookupCachedUnit;
    QQmlPrivate::qmlregister(QQmlPrivate::QmlUnitCacheHookRegistration, &registration);
QT_PREPEND_NAMESPACE(qRegisterResourceData)(/*version*/0x01, qt_resource_tree, qt_resource_names, qt_resource_empty_payout);
}

Registry::~Registry() {
    QQmlPrivate::qmlunregister(QQmlPrivate::QmlUnitCacheHookRegistration, quintptr(&lookupCachedUnit));
}

const QQmlPrivate::CachedQmlUnit *Registry::lookupCachedUnit(const QUrl &url) {
    if (url.scheme() != QLatin1String("qrc"))
        return nullptr;
    QString resourcePath = QDir::cleanPath(url.path());
    if (resourcePath.isEmpty())
        return nullptr;
    if (!resourcePath.startsWith(QLatin1Char('/')))
        resourcePath.prepend(QLatin1Char('/'));
    return unitRegistry()->resourcePathToCachedUnit.value(resourcePath, nullptr);
}
}
int QT_MANGLE_NAMESPACE(qInitResources_dashboard)() {
    ::unitRegistry();
    Q_INIT_RESOURCE(dashboard_qmlcache);
    return 1;
}
Q_CONSTRUCTOR_FUNCTION(QT_MANGLE_NAMESPACE(qInitResources_dashboard))
int QT_MANGLE_NAMESPACE(qCleanupResources_dashboard)() {
    Q_CLEANUP_RESOURCE(dashboard_qmlcache);
    return 1;
}
